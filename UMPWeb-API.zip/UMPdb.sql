CREATE DATABASE  IF NOT EXISTS `usermanagementdb` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `usermanagementdb`;
-- MySQL dump 10.13  Distrib 8.0.44, for Win64 (x86_64)
--
-- Host: localhost    Database: usermanagementdb
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `__efmigrationshistory`
--

DROP TABLE IF EXISTS `__efmigrationshistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `__efmigrationshistory` (
  `MigrationId` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `ProductVersion` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`MigrationId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `__efmigrationshistory`
--

LOCK TABLES `__efmigrationshistory` WRITE;
/*!40000 ALTER TABLE `__efmigrationshistory` DISABLE KEYS */;
INSERT INTO `__efmigrationshistory` VALUES ('20251112095353_InitialCreate','9.0.0'),('20251112110245_AddRole','9.0.0'),('20251112110846_AddModify','9.0.0'),('20251112133502_ModifyPassword','9.0.0'),('20251115051908_AddCreate','9.0.0'),('20251117163108_AddDate','9.0.0'),('20251118075833_Initial','9.0.0'),('20251118163849_ReduceRoleNameLength','9.0.0');
/*!40000 ALTER TABLE `__efmigrationshistory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mastergenders`
--

DROP TABLE IF EXISTS `mastergenders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mastergenders` (
  `GenderId` int NOT NULL AUTO_INCREMENT,
  `GenderName` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`GenderId`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mastergenders`
--

LOCK TABLES `mastergenders` WRITE;
/*!40000 ALTER TABLE `mastergenders` DISABLE KEYS */;
INSERT INTO `mastergenders` VALUES (1,'Male'),(2,'Female'),(3,'Other');
/*!40000 ALTER TABLE `mastergenders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `masterroles`
--

DROP TABLE IF EXISTS `masterroles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `masterroles` (
  `RoleId` int NOT NULL AUTO_INCREMENT,
  `RoleName` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`RoleId`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `masterroles`
--

LOCK TABLES `masterroles` WRITE;
/*!40000 ALTER TABLE `masterroles` DISABLE KEYS */;
INSERT INTO `masterroles` VALUES (1,'Admin'),(2,'Customer'),(3,'Retailer');
/*!40000 ALTER TABLE `masterroles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `FullName` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Mobile` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Password` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `BirthDate` date NOT NULL,
  `Email` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `CreatedAt` datetime(6) NOT NULL DEFAULT '0001-01-01 00:00:00.000000',
  `GenderId` int NOT NULL DEFAULT '0',
  `RoleId` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`Id`),
  KEY `IX_Users_GenderId` (`GenderId`),
  KEY `IX_Users_RoleId` (`RoleId`),
  CONSTRAINT `FK_Users_MasterGenders_GenderId` FOREIGN KEY (`GenderId`) REFERENCES `mastergenders` (`GenderId`) ON DELETE CASCADE,
  CONSTRAINT `FK_Users_MasterRoles_RoleId` FOREIGN KEY (`RoleId`) REFERENCES `masterroles` (`RoleId`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (2,'arjun','8785885859','$2a$11$HARlDUy9FZbxFk8XCcYLo.MX2bkbmDtch52heHl6AStJ2QR2WSepW','1998-09-18','arjun@gmail.com','2025-11-18 08:24:55.233663',1,1),(3,'sai','8995969006','$2a$11$WYzkS.7S6LT59QfTtiKvX.fgFi8UPp6pyAaycEfKr/q3JM7PcODTS','2003-09-18','sai@gmail.com','2025-11-18 09:36:30.051229',2,3),(4,'deva','9866789999','$2a$11$xcyA2ghGo8BX8hDnVU2Ktu7qW3wg97eJ7icPp9fJVbtXPSVOdp/ia','1968-07-18','deva@gmail.com','2025-11-18 10:01:45.850286',1,3),(6,'shiva','8596869596','$2a$11$Y0KI2KnoQoFExb5QlqXsee4jEApnmwp1u7lW48bqsmwsOV6zTWxD.','1990-08-19','shiva@gmail.com','2025-11-18 10:29:24.324676',1,2),(7,'roopesh','8959590500','$2a$11$o/TSmgRxHx2tEmzHKqMiouHE2o03UH9RsiS4gYWRqUx.UmE.SV8Wq','2000-02-19','roopesh@gmail.com','2025-11-18 10:38:45.393152',1,2),(8,'suresh','9859959959','$2a$11$NdYKjos65PUSGUsHr.ep8OQ9qpofdeAFtVt.f/Z9aKEDVlTCwhA1q','2000-08-07','suresh@gmail.com','2025-11-18 10:49:43.386292',1,2),(10,'prem','8459450045','$2a$11$aSYLaYpivDfdyDDuuvIOL.548drOFbnFNo6zseGSltpOul71Mg8tW','2000-08-19','prema@gmail.com','2025-11-18 11:54:19.257075',2,1),(11,'varun','7886589997','$2a$11$pD9BrlOvv4s7trj5TYEOMOBWYaLO2j109oKGjjesYBWbzFKyokAT6','1989-02-09','varun@gmail.com','2025-11-18 12:06:26.698921',1,1),(12,'megha','8997849958','$2a$11$UaMMbkq/8sHLl1tjbe6WUe0IRqHvsdCzEx.1M46kGJr6x9f9XWrPC','1980-08-19','megha@gmail.com','2025-11-18 12:08:28.052516',2,2),(16,'teja','8478848488','$2a$11$Nm7C8n30Ain.ucywEXJAkedW2Ajm0P8YZACXjrBGfimSK/WQTJB..','1890-08-19','teja@gmail.com','2025-11-18 12:16:33.881355',1,1),(17,'deepan','8589599595','$2a$11$2tfRRnlfjBXZCoYZVXXhTezilVo4jAxU1h5U4jMBdD9uZxiIuBYw.','2002-08-19','deepan@gmail.com','2025-11-18 12:20:02.884992',1,1),(18,'saran','9498997783','$2a$11$KtUfZoXlvHisT2CdSNBDsOrlZtTrz2W5WtBLH6p7KYczXdNWBm8Eu','2003-08-09','saran@gmail.com','2025-11-18 12:21:00.356987',1,3),(19,'navya','9885998948','$2a$11$i8IXA3GQaFEJxF7T5RSL2eexOO.QSGuRB7mIyIIF5SpcaZPPJ4l2q','1976-08-19','navya@gmail.com','2025-11-18 12:42:19.054393',2,3),(20,'venu','8887757858','$2a$11$ve849nbeHEHb.shAX6mSqOntDT7n.H4N1.IvUt4UDwR6koTrwEp4S','2000-08-19','venu@gmail.com','2025-11-18 12:44:06.227619',1,1),(21,'bhanu','9899488780','$2a$11$RWjt7WBIyyjv3U4CcoHh6O6JO/XTl2gjOCDPD3vq1TGVz9IA5jm.u','1898-06-15','bhanu@gmail.com','2025-11-18 13:04:29.753447',2,2),(22,'pavan','8959585985','$2a$11$WroKXXPgJl76r1wB0F.ULukVivaR5AbEe1fQg.9zo6qgJkuahwY3q','1899-07-18','pavan@gmail.com','2025-11-18 13:05:13.525406',1,2),(24,'pardhu','9459959599','$2a$11$1EI4kCui8hiaENzsMQDS0.tg7GbBLa7t.9VkfB5.u9YO1dVkoSFaG','2002-03-12','pardhu@gmail.com','2025-11-18 13:13:35.117565',1,2),(25,'manu','8949485959','$2a$11$crrcgrKbcZgKx18zJuw4g.JU246uIJPHhccY5cKFNdFOFYARI/wKC','1989-08-19','manu@gmail.com','2025-11-18 13:17:22.248002',1,3),(26,'varun','9897789978','$2a$11$bt1XXy9yezNYuACzCyJt/eKW16UkbRenfu2heN4t/IdiyQrS6elsO','2000-04-12','var@gmail.com','2025-11-18 13:19:51.094599',1,2),(27,'ammu','8996778899','$2a$11$FvyqCNcou282.H.1qLPoHOdRC9zw3/QA3OBGeEaqlKxdrvNcBQkaS','1978-04-18','ammu@gmail.com','2025-11-18 16:18:32.063822',2,2),(28,'neha','8975467898','$2a$11$SM4E2/z992.oK5pKkdqS.eTCOTf3crBauuMSjRQzo6E0j3VK.sHgm','2000-06-07','neha@gmail.com','2025-11-18 16:19:48.992356',2,2),(29,'yami','9989999876','$2a$11$Fs/wrB695PvcoRAn2TrsyuK6zvgsrEX9cE.xLENIPf8lqgVKNvhvC','1879-05-16','yami@gmail.com','2025-11-18 16:43:30.273004',2,2),(30,'druthi','9876679987','$2a$11$.2RDYgO5xiFgxx16MPSxYuT78upuCDCdECcwv80HYSddsKGaKNryS','1890-08-09','druthi@gamil.com','2025-11-18 16:44:19.994390',2,1);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'usermanagementdb'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-18 22:18:10
