import React from "react";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import Login from "../pages/Login";
import SignUp from "../pages/Signup";
import Dashboard from "../pages/Dashboard";
import ManageUsers from "../pages/ManageUsers";
import ProtectedRoute from "./ProtectedRoute";
import Home from "../screens/Home";

const AppRoutes: React.FC = () => {
  const isLoggedIn = sessionStorage.getItem("currentUser");

  return (
    <BrowserRouter>
      <Routes>
        <Route
          path="/login"
          element={isLoggedIn ? <Navigate to="/dashboard" replace /> : <Login />}
        />
        <Route
          path="/signup"
          element={isLoggedIn ? <Navigate to="/dashboard" replace /> : <SignUp />}
        />

        <Route
          path="/dashboard"
          element={
            <ProtectedRoute>
              <Dashboard />
            </ProtectedRoute>
          }
        />

        <Route
          path="/manageusers"
          element={
            <ProtectedRoute>
              <ManageUsers />
            </ProtectedRoute>
          }
        />

        <Route
          path="*"
          element={isLoggedIn ? <Navigate to="/dashboard" replace /> : <Home />}
        />
      </Routes>
    </BrowserRouter>
  );
};

export default AppRoutes;
