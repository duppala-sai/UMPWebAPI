import React from "react";
import { Link } from "react-router-dom";

const Home: React.FC = () => {
  return (
    <div
      className="h-screen w-screen bg-cover bg-center bg-no-repeat flex flex-col justify-between overflow-hidden"
      style={{
        backgroundImage: "url('/images/background.png')",
        backgroundAttachment: "fixed",
        
      }}
    >
      <header className="flex justify-between items-center p-6">
        <div className="flex items-center">
          <img src="/images/icon.png" alt="Logo" className="h-12 w-12 mr-3" />
          <h1 className="text-white text-xl font-semibold font-serif tracking-wide">
            UMP
          </h1>
        </div>

        <div className="flex items-center space-x-4 rounded-lg">
          <Link
            to="/login"
            className="px-4 pt-1 pb-2 border border-white text-white rounded-md bg-green-600 transition-transform duration-200 ease-in-out transform hover:scale-105"
          >
            Login
          </Link>
          <Link
            to="/signup"
            className="px-4 pt-1 pb-2 border border-white text-gray-800 rounded-md  bg-gray-200 transition-transform duration-200 ease-in-out transform hover:scale-105"
          >
            Signup
          </Link>
        </div>
      </header>

      <main className="flex flex-col justify-center items-start text-white text-left px-4 ml-24 grow">
        <h2 className="text-4xl font-bold mb-4">Welcome to the Portal</h2>
        <p className="text-lg max-w-2xl mb-6">
          UMP (User Management Portal) helps you easily manage users with powerful
          control tools. Whether it's access, roles, or permissions — you’re in charge.
        </p>

        <div className="flex space-x-4 mt-4">
          <Link
            to="/login"
            className="px-4 py-1 border border-white text-white rounded-md bg-green-600 transition-transform duration-200 ease-in-out transform hover:scale-105"
          >
            Get Started
          </Link>
          <Link
            to="/signup"
            className="px-4 py-1 border border-white text-gray-800 rounded-md bg-gray-200 transition-transform duration-200 ease-in-out transform hover:scale-105"
          >
            Create Account
          </Link>
        </div>
      </main>
    </div>
  );
};

export default Home;
