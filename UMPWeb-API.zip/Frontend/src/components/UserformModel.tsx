import React, { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import { toast } from "react-toastify";
import api from "../API/axiosConfig";

interface UserFormProps {
  close: (didChange?: boolean) => void;
  existingUser?: any;
}

interface Role {
  roleId: number;
  roleName: string;
}

interface Gender {
  genderId: number;
  genderName: string;
}

const today = new Date();
const minDOB = new Date(today.getFullYear() - 18, today.getMonth(), today.getDate());

const UserForm: React.FC<UserFormProps> = ({ close, existingUser }) => {
  const [roles, setRoles] = useState<Role[]>([]);
  const [genders, setGenders] = useState<Gender[]>([]);

  const schema = yup.object().shape({
    fullname: yup.string().required("Full Name is required"),
    email: yup.string().email("Invalid email format").required("Email is required"),
    password: existingUser
      ? yup.string().notRequired()
      : yup.string().required("Password is required").min(6, "Password must be at least 6 characters"),
    roleId: yup.number().required("Role is required").typeError("Role is required"),
    mobile: yup
      .string()
      .matches(/^\d{10}$/, "Mobile must be 10 digits")
      .required("Mobile is required"),
    genderId: yup.number().required("Gender is required").typeError("Gender is required"),
    birthDate: yup
      .string()
      .required("Date of Birth is required")
      .test("is-18+", "You must be at least 18 years old", function (value) {
        if (!value) return false;
        return new Date(value) <= minDOB;
      }),
  });

  const { register, handleSubmit, setValue, formState: { errors } } = useForm({
    resolver: yupResolver(schema),
  });

  // Fetch roles and genders 
useEffect(() => {
  const fetchLookups = async () => {
    try {
      const res = await fetch("https://localhost:7298/api/Users/masterdata");
      if (!res.ok) throw new Error("Failed to fetch lookups");
      const data = await res.json(); 
      setRoles(data.roles);
      setGenders(data.genders);
    } catch (error) {
      console.error(error);
    }
  };

  fetchLookups();
}, []);


  // Prefill form for edit (using string matching for role/gender)
  useEffect(() => {
    if (existingUser && roles.length > 0 && genders.length > 0) {
      setValue("fullname", existingUser.fullName);
      setValue("email", existingUser.email);
      setValue("mobile", existingUser.mobile);

      // Match role name to ID
      const roleObj = roles.find(r => r.roleName === existingUser.role);
      if (roleObj) setValue("roleId", roleObj.roleId);

      // Match gender name to ID
      const genderObj = genders.find(g => g.genderName === existingUser.gender);
      if (genderObj) setValue("genderId", genderObj.genderId);

      if (existingUser.birthDate) {
        const date = new Date(existingUser.birthDate);
        const yyyy = date.getFullYear();
        const mm = String(date.getMonth() + 1).padStart(2, "0");
        const dd = String(date.getDate()).padStart(2, "0");
        setValue("birthDate", `${yyyy}-${mm}-${dd}`);
      }
    }
  }, [existingUser, roles, genders, setValue]);

  const onSubmit = async (data: any) => {
    try {
      if (existingUser) {
        const updateData = {
          fullName: data.fullname,
          mobile: data.mobile,
          roleId: data.roleId,
          genderId: data.genderId,
          birthDate: data.birthDate,
        };
        await api.put(`/Users/${existingUser.email}`, updateData);
        toast.success("User updated successfully!");
      } else {
        await api.post("/Users/register", data);
        toast.success("User added successfully!");
      }
      close(true);
    } catch (error: any) {
      console.error(error);
      const msg = error?.response?.data?.message || error?.message || "Operation failed!";
      toast.error(msg);
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-lg w-96 p-6 relative transform transition-transform duration-200 scale-95 animate-scaleUp max-h-[90vh] overflow-auto">
      <h2 className="text-xl font-semibold text-center mb-4">
        {existingUser ? "Edit User" : "Add New User"}
      </h2>

      <form onSubmit={handleSubmit(onSubmit)} className="flex flex-col">
        <div className="mb-3 w-full">
          <input type="text" placeholder="Full Name" {...register("fullname")} className="border rounded p-1.5 w-full" />
          {errors.fullname && <p className="error-text">{errors.fullname.message}</p>}
        </div>

        <div className="mb-3 w-full">
          <input type="email" placeholder="Email" {...register("email")} disabled={!!existingUser} className="border rounded p-1.5 w-full" />
          {errors.email && <p className="error-text">{errors.email.message}</p>}
        </div>

        {!existingUser && (
          <div className="mb-3 w-full">
            <input type="password" placeholder="Password" {...register("password")} className="border rounded p-1.5 w-full" />
            {errors.password && <p className="error-text">{errors.password.message}</p>}
          </div>
        )}

        <div className="mb-3 w-full">
          <select {...register("roleId")} className="border rounded p-1.5 w-full">
            <option value="">Select Role</option>
            {roles.map(role => (
              <option key={role.roleId} value={role.roleId}>{role.roleName}</option>
            ))}
          </select>
          {errors.roleId && <p className="error-text">{errors.roleId.message}</p>}
        </div>

        <div className="mb-3 w-full">
          <input type="tel" placeholder="Mobile Number" {...register("mobile")} maxLength={10} className="border rounded p-1.5 w-full" />
          {errors.mobile && <p className="error-text">{errors.mobile.message}</p>}
        </div>

        <div className="mb-3 w-full">
          <select {...register("genderId")} className="border rounded p-1.5 w-full">
            <option value="">Select Gender</option>
            {genders.map(gender => (
              <option key={gender.genderId} value={gender.genderId}>{gender.genderName}</option>
            ))}
          </select>
          {errors.genderId && <p className="error-text">{errors.genderId.message}</p>}
        </div>

        <div className="mb-3 w-full">
          <input type="date" {...register("birthDate")} className="border rounded p-1.5 w-full" />
          {errors.birthDate && <p className="error-text">{errors.birthDate.message}</p>}
        </div>

        <div className="flex justify-end gap-3 mt-2.5">
          <button type="submit" className="bg-green-600 text-white px-4 py-1 rounded hover:bg-green-700 transition">
            {existingUser ? "Update" : "Add"}
          </button>
          <button type="button" onClick={() => close(false)} className="bg-gray-500 text-white px-4 py-1 rounded hover:bg-gray-600 transition">
            Cancel
          </button>
        </div>
      </form>
    </div>
  );
};

export default UserForm;
