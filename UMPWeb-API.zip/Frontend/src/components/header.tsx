import React from 'react';
import { NavLink } from 'react-router-dom';

const Header: React.FC = () => {
  const storedUser = sessionStorage.getItem("currentUser");
  const user = storedUser ? JSON.parse(storedUser) : null;

  const handleLogout = () => {
    sessionStorage.removeItem("currentUser");
    window.location.href = "/login";
  };

  return (
    <header className="bg-indigo-950 text-white fixed top-0 left-0 w-full shadow-lg z-50">
      <div className="flex justify-between items-center h-20 px-4 sm:px-8">

        <div className="flex items-center space-x-2 sm:space-x-4">
          <img
            src="/images/icon.png"
            alt="UMP Logo"
            className="w-12 h-12"
          />
          <h1 className="text-white text-xl font-semibold font-serif tracking-wide">UMP</h1>
        </div>

        <nav className="flex space-x-8 text-md ">
          <NavLink
            to="/dashboard"
            className={({ isActive }) =>
              `hover:text-gray-200 transition ${isActive ? "border-b-2 border-white" : ""}`
            }
          >
            Dashboard
          </NavLink>
          <NavLink
            to="/manageusers"
            className={({ isActive }) =>
              `hover:text-gray-200 transition ${isActive ? "border-b-2 border-white" : ""}`
            }
          >
            Manage Users
          </NavLink>
        </nav>

        <div className="flex items-center space-x-3 sm:space-x-4">
          <span className="inline font-medium text-lg ">
            {user ? user.fullName : "Guest"}
          </span>
          <button
            onClick={handleLogout}
            className="hover:text-gray-200 transition"
            title="Logout"
          >
            <i className="fas fa-sign-out-alt text-2xl"></i>
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;
