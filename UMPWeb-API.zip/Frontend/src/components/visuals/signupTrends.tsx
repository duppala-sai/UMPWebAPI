import React, { useMemo } from "react";
import { Card, Typography } from "@mui/material";
import { BarChart } from "@mui/x-charts";

interface SignupTrendsProps {
  allUsers: any[];
}

const SignupTrends: React.FC<SignupTrendsProps> = ({ allUsers }) => {
  // Compute monthly trends from allUsers
  const monthlyData = useMemo(() => {
    const months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
    const counts = new Array(12).fill(0);

    allUsers.forEach(user => {
      if (user.createdAt) {
        const monthIndex = new Date(user.createdAt).getMonth();
        counts[monthIndex]++;
      }
    });

    return months.map((month, i) => ({ month, count: counts[i] }));
  }, [allUsers]);

  return (
    <div className="w-full max-w-xl">
      <Card className="p-4 rounded-xl shadow-lg">
        <Typography variant="h6" align="center" className="mb-4 font-semibold">
          Monthly Signup Trends (Jan–Dec)
        </Typography>

        <BarChart
          xAxis={[{ data: monthlyData.map(m => m.month), scaleType: "band" }]}
          series={[{ data: monthlyData.map(m => m.count), label: "Signups", color: "#2563EB" }]}
          width={300}
          height={200}
        />
      </Card>
    </div>
  );
};

export default SignupTrends;
