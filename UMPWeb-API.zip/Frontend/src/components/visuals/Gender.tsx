import React from "react";
import { Card, Typography } from "@mui/material";
import { PieChart } from "@mui/x-charts";

interface GenderDistributionProps {
  allUsers: any[];
}

const GenderDistribution: React.FC<GenderDistributionProps> = ({ allUsers }) => {
  const genderCounts = allUsers.reduce(
    (count: Record<string, number>, user) => {
      const gender = user.gender?.toLowerCase();
      if (gender === "male" || gender === "female") {
        count[gender] = (count[gender] || 0) + 1;
      }
      return count;
    },
    { male: 0, female: 0 }
  );

  const genderData = [
    { id: 0, value: genderCounts.male, label: "Male", color: "#3B82F6" },
    { id: 1, value: genderCounts.female, label: "Female", color: "#EC4899" },
  ];

  return (
    <Card className="p-4 rounded-xl shadow-lg  w-full max-w-xl">
      <Typography variant="h6" align="center" className="mb-4 font-semibold">
        Gender Insights
      </Typography>
      <PieChart
        series={[{ data: genderData, innerRadius: 60, outerRadius: 100 }]}
        width={300}
        height={200}
      />
    </Card>
  );
};

export default GenderDistribution;
