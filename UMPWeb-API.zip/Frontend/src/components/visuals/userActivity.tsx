import React from "react";
import { Card, Typography } from "@mui/material";
import { PieChart } from "@mui/x-charts";

interface UserActivityPieProps {
  allUsers: any[];
}

const UserActivity: React.FC<UserActivityPieProps> = ({ allUsers }) => {
  const storedUser = sessionStorage.getItem("currentUser");
  const currentUser = storedUser ? JSON.parse(storedUser) : null;

  const activeUsersCount = currentUser ? 1 : 0;
  const inactiveUsersCount = allUsers.length - activeUsersCount;

  const data = [
    { id: 0, value: activeUsersCount, label: "Active", color: "#22C55E" },
    { id: 1, value: inactiveUsersCount, label: "Inactive", color: "#F87171" },
  ];

  return (
    <Card className="p-4 rounded-xl shadow-lg w-full max-w-xl">
      <Typography variant="h6" align="center" className="mb-4 font-semibold">
        Activity Status
      </Typography>
      <PieChart series={[{ data, outerRadius: 100, innerRadius: 60 }]} width={300} height={200} />
    </Card>
  );
};

export default UserActivity;
