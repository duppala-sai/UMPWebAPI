import React from "react";

interface RoleDistributionCardsProps {
  allUsers: any[];
}

const Role: React.FC<RoleDistributionCardsProps> = ({ allUsers }) => {
  const defaultRoles = ["Admin", "Customer", "Retailer"];
  const roleCounts: Record<string, number> = allUsers.reduce(
    (count: Record<string, number>, user) => {
      const role = user.role || "Other";
      count[role] = (count[role] || 0) + 1;
      return count;
    },
    defaultRoles.reduce((count, role) => ({ ...count, [role]: 0 }), {})
  );

  const roleGradientMap: Record<string, string> = {
    Admin: "bg-linear-to-r from-blue-400 to-indigo-800",
    Customer: "bg-linear-to-r from-green-500 to-teal-600",
    Retailer: "bg-linear-to-r from-purple-500 to-pink-500"
  };

  return (
    <div className="flex flex-wrap gap-10 justify-center w-full">
      {Object.entries(roleCounts).map(([role, count]) => (
        <div
          key={role}
          className={`${roleGradientMap[role] || "bg-gray-400"} 
                     p-8 rounded-2xl shadow-xl text-white 
                     flex flex-col items-center justify-center duration-300
                     hover:scale-105 transform transition min-w-[250px] md:min-w-[300px]`}
        >
          <h2 className="text-2xl md:text-3xl font-semibold">{role}</h2>
          <p className="text-4xl md:text-5xl font-bold">{count}</p>
        </div>
      ))}
    </div>
  );
};

export default Role;
