import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import api from "../API/axiosConfig"; 

function Login() {
  const [data, setData] = useState({ email: "", password: "" });
  const navigate = useNavigate();

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    try {
      const response = await api.post("/Users/login", {
        email: data.email,
        password: data.password
      });

      sessionStorage.setItem("currentUser", JSON.stringify(response.data));
      toast.success("Login successful!");
      navigate("/dashboard");
    } catch (error: any) {
      toast.error(error?.response?.data?.message || "Invalid Email or Password!");
    }
  };

  return (
    <div
      className="h-screen bg-cover bg-center bg-fixed flex flex-col justify-center items-center"
      style={{ backgroundImage: "url('/images/background.png')" }}
    >
      <div className="relative w-85">
        <img
          src="/images/icon.png"
          alt="Logo"
          className="h-14 w-14 absolute -top-7 left-1/2 transform -translate-x-1/2 bg-white rounded-full p-1 border border-gray-300"
        />

        <form
          onSubmit={handleSubmit}
          className="rounded-xl p-10 bg-white bg-opacity-90 border border-gray-300 shadow-xl w-full"
        >
          <h2 className="text-2xl font-semibold text-center mb-6">Login</h2>

          <input
            type="email"
            name="email"
            value={data.email}
            onChange={handleChange}
            placeholder="Email"
            required
            className="rounded mb-4 p-2 border border-gray-300 w-full focus:outline-none focus:border-green-500"
          />

          <input
            type="password"
            name="password"
            value={data.password}
            onChange={handleChange}
            placeholder="Password"
            required
            className="rounded mb-6 p-2 border border-gray-300 w-full focus:outline-none focus:border-green-500"
          />

          <button
            type="submit"
            className="w-full py-2 rounded-md bg-green-700 text-white font-semibold hover:bg-green-800 transition"
          >
            Login
          </button>

          <p className="text-center text-sm text-gray-700 mt-4">
            Not a member?{" "}
            <Link
              to="/signup"
              className="text-green-700 font-semibold hover:underline hover:text-green-900"
            >
              Sign Up
            </Link>
          </p>
        </form>
      </div>
    </div>
  );
}

export default Login;
