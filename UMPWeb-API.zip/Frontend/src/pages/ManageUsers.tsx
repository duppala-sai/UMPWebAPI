import React, { useState, useEffect } from "react";
import Header from "../components/header";
import UserForm from "../components/UserformModel";
import DeletePopup from "../components/DeletePopup";
import api from "../API/axiosConfig";
import { toast } from "react-toastify";

interface User {
  fullName: string;
  email: string;
  role: string;
  gender: string;
  mobile: string;
  birthDate: string;
}

const ManageUsers: React.FC = () => {
  const [showForm, setShowForm] = useState(false);
  const [editUser, setEditUser] = useState<User | null>(null);
  const [allUsers, setAllUsers] = useState<User[]>([]);

  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState<User | null>(null);

  const fetchUsers = async () => {
    try {
      const res = await api.get("/Users");
      setAllUsers(res.data);
    } catch (error) {
      console.error(error);
      toast.error("Failed to fetch users.");
    }
  };

  // Fetch users on mount
  useEffect(() => {
    fetchUsers();
  }, []);

  const handleAddUser = () => {
    setEditUser(null);
    setShowForm(true);
  };

  const handleEdit = (user: User) => {
    setEditUser(user);
    setShowForm(true);
  };

  const handleDeleteClick = (user: User) => {
    setSelectedUser(user);
    setIsDeleteModalOpen(true);
  };

  const handleConfirmDelete = async () => {
    if (!selectedUser) return;
    try {
      await api.delete(`/Users/${selectedUser.email}`);
      toast.success("User deleted successfully!");
      fetchUsers();
    } catch (error) {
      console.error(error);
      toast.error("Failed to delete user.");
    } finally {
      setIsDeleteModalOpen(false);
      setSelectedUser(null);
    }
  };

  const handleCancelDelete = () => {
    setIsDeleteModalOpen(false);
    setSelectedUser(null);
  };

  // Lock scroll when modal/form is open
  useEffect(() => {
    document.body.style.overflow = showForm || isDeleteModalOpen ? "hidden" : "auto";
    return () => { document.body.style.overflow = "auto"; };
  }, [showForm, isDeleteModalOpen]);

  return (
    <>
      <Header />
      <div className="flex flex-col items-center bg-blue-50 mt-20 px-6 md:px-12 pb-10 space-y-8 min-h-screen">
        <div className="text-gray-800 text-center text-lg mt-8 italic font-semibold max-w-3xl mx-auto">
          A simple and clean way to manage system users. Easily browse, edit, or remove user information from the panel below.
        </div>

        <button onClick={handleAddUser} className="bg-green-600 text-white font-semibold px-6 py-2 rounded-lg shadow-md transition-all hover:bg-green-700 hover:scale-105">
          + Add New User
        </button>

        <div className="w-full max-w-6xl overflow-x-auto rounded-lg shadow-md bg-white">
          <table className="w-full border-collapse">
            <thead className="bg-purple-200">
              <tr>
                <th className="px-4 py-3 text-left text-sm font-semibold">Name</th>
                <th className="px-4 py-3 text-left text-sm font-semibold">Email</th>
                <th className="px-4 py-3 text-left text-sm font-semibold">Role</th>
                <th className="px-4 py-3 text-left text-sm font-semibold">Gender</th>
                <th className="px-4 py-3 text-left text-sm font-semibold">Mobile</th>
                <th className="px-4 py-3 text-left text-sm font-semibold">BirthDate</th>
                <th className="px-4 py-3 text-center text-sm font-semibold">Actions</th>
              </tr>
            </thead>
            <tbody>
              {allUsers.map((user, i) => (
                <tr key={i} className="border-t hover:bg-blue-50 transition-all">
                  <td className="px-4 py-3 text-sm text-gray-800">{user.fullName}</td>
                  <td className="px-4 py-3 text-sm text-gray-800">{user.email}</td>
                  <td className="px-4 py-3 text-sm text-gray-800">{user.role}</td>
                  <td className="px-4 py-3 text-sm text-gray-800">{user.gender}</td>
                  <td className="px-4 py-3 text-sm text-gray-800">{user.mobile}</td>
                  <td className="px-4 py-3 text-sm text-gray-800">{user.birthDate}</td>
                  <td className="px-4 py-3 text-sm text-center flex items-center justify-center gap-3">
                    <button onClick={() => handleEdit(user)} className="px-3 py-1 bg-blue-500 text-white rounded-md text-sm hover:bg-blue-600 transition">Edit</button>
                    <button onClick={() => handleDeleteClick(user)} className="px-3 py-1 bg-red-500 text-white rounded-md text-sm hover:bg-red-600 transition">Delete</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {showForm && (
          <div className="fixed inset-0 bg-black/30 z-50 flex justify-center items-start overflow-auto pt-10 pb-10">
            <UserForm
              close={(didChange?: boolean) => {
                setShowForm(false);
                if (didChange) fetchUsers();
              }}
              existingUser={editUser}
            />
          </div>
        )}

        <DeletePopup
          isOpen={isDeleteModalOpen && selectedUser !== null}
          userName={selectedUser?.fullName || ""}
          onConfirm={handleConfirmDelete}
          onCancel={handleCancelDelete}
        />
      </div>
    </>
  );
};

export default ManageUsers;
