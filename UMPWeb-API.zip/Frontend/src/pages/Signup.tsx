import React, { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import type { SubmitHandler } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import { toast } from "react-toastify";
import { useNavigate } from "react-router-dom";
import api from "../API/axiosConfig";

interface SignUpFormData {
  fullname: string;
  email: string;
  password: string;
  roleId: number;
  mobile: string;
  genderId: number;
  birthDate: string; 
}

interface Role {
  roleId: number;
  roleName: string;
}

interface Gender {
  genderId: number;
  genderName: string;
}

const today = new Date();
const minDOB = new Date(today.getFullYear() - 18, today.getMonth(), today.getDate());

const schema = yup.object().shape({
  fullname: yup.string().required("Full Name is required"),
  email: yup
    .string()
    .email("Invalid email format")
    .matches(/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/, "Email must be valid")
    .required("Email is required"),
  password: yup.string().min(6, "Password must be at least 6 characters").required("Password is required"),
  roleId: yup.number().required("Role is required").typeError("Role is required"),
  mobile: yup.string().matches(/^\d{10}$/, "Mobile must be 10 digits").required("Mobile is required"),
  genderId: yup.number().required("Gender is required").typeError("Gender is required"),
  birthDate: yup
    .string()
    .required("Date of Birth is required")
    .test("is-18+", "You must be at least 18 years old", function (value) {
      if (!value) return false;
      return new Date(value) <= minDOB;
    }),
});

const SignUp: React.FC = () => {
  const navigate = useNavigate();
  const { register, handleSubmit, formState: { errors } } = useForm<SignUpFormData>({
    resolver: yupResolver(schema)
  });

  const [roles, setRoles] = useState<Role[]>([]);
  const [genders, setGenders] = useState<Gender[]>([]);

  // Fetch roles and genders using fetch
  useEffect(() => {
  const fetchLookups = async () => {
    try {
      const res = await fetch("https://localhost:7298/api/Users/masterdata");
      if (!res.ok) throw new Error("Failed to fetch lookups");
      const data = await res.json(); // data should have { roles: [...], genders: [...] }
      setRoles(data.roles);
      setGenders(data.genders);
    } catch (error) {
      console.error(error);
    }
  };

  fetchLookups();
}, []);


  const onSubmit: SubmitHandler<SignUpFormData> = async (data) => {
    try {
      await api.post("/Users/register", data);
      toast.success("Registration successful!");
      navigate("/login");
    } catch (error: any) {
      console.error(error);
      toast.error(error?.response?.data?.message || "Registration failed!");
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center bg-cover bg-center bg-fixed overflow-auto p-4"
         style={{ backgroundImage: "url('/images/background.png')" }}>
      <div className="flex flex-col items-center w-full max-w-xs mt-10 mb-20 relative">
        <img src="/images/icon.png" alt="Logo"
             className="h-14 w-14 absolute -top-7 left-1/2 transform -translate-x-1/2 bg-white rounded-full p-1 border border-gray-300"/>
        <form onSubmit={handleSubmit(onSubmit)}
              className="rounded-xl p-8 bg-white bg-opacity-90 border border-gray-300 shadow-xl w-90">
          <h2 className="text-2xl font-semibold text-center mb-6">Sign Up</h2>

          <div className="mb-2 w-full">
            <input type="text" placeholder="Full Name" {...register("fullname")}
                   className="rounded p-1.5 border border-gray-300 w-full"/>
            {errors.fullname && <p className="error-text">{errors.fullname.message}</p>}
          </div>

          <div className="mb-2 w-full">
            <input type="email" placeholder="Email" {...register("email")}
                   className="rounded p-1.5 border border-gray-300 w-full"/>
            {errors.email && <p className="error-text">{errors.email.message}</p>}
          </div>

          <div className="mb-2 w-full">
            <input type="password" placeholder="Password" {...register("password")}
                   className="rounded p-1.5 border border-gray-300 w-full"/>
            {errors.password && <p className="error-text">{errors.password.message}</p>}
          </div>

          <div className="mb-2 w-full">
            <select {...register("roleId")} className="rounded p-1.5 border border-gray-300 w-full">
              <option value="">Select role</option>
              {roles.map(role => (
                <option key={role.roleId} value={role.roleId}>{role.roleName}</option>
              ))}
            </select>
            {errors.roleId && <p className="error-text">{errors.roleId.message}</p>}
          </div>

          <div className="mb-2 w-full">
            <input type="tel" maxLength={10} placeholder="Mobile Number" {...register("mobile")}
                   className="rounded p-1.5 border border-gray-300 w-full"/>
            {errors.mobile && <p className="error-text">{errors.mobile.message}</p>}
          </div>

          <div className="mb-2 w-full">
            <select {...register("genderId")} className="rounded p-1.5 border border-gray-300 w-full">
              <option value="">Select Gender</option>
              {genders.map(gender => (
                <option key={gender.genderId} value={gender.genderId}>{gender.genderName}</option>
              ))}
            </select>
            {errors.genderId && <p className="error-text">{errors.genderId.message}</p>}
          </div>

          <div className="mb-4 w-full">
            <input type="date" {...register("birthDate")}
                   className="rounded p-1.5 border border-gray-300 w-full"/>
            {errors.birthDate && <p className="error-text">{errors.birthDate.message}</p>}
          </div>

          <button type="submit"
                  className="w-full py-2 rounded-md bg-green-700 text-white font-semibold hover:bg-green-800 transition">
            Register
          </button>
        </form>
      </div>
    </div>
  );
};

export default SignUp;
