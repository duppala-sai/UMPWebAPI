import React, { useEffect, useState } from "react";
import Header from "../components/header";
import Role from "../components/visuals/Role";
import UserActivity from "../components/visuals/userActivity";
import AgeDistribution from "../components/visuals/AgeDistribution";
import SignupTrends from "../components/visuals/signupTrends";
import GenderDistribution from "../components/visuals/Gender";
import api from "../API/axiosConfig";

const Dashboard: React.FC = () => {
  const [allUsers, setAllUsers] = useState<any[]>([]);

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const response = await api.get("/Users");
        setAllUsers(response.data);
      } catch (error) {
        console.error("Failed to load users:", error);
      }
    };

    fetchUsers();
  }, []);

  // Block back button 
  useEffect(() => {
    window.history.pushState(null, "", window.location.href);
    const blockBack = () => window.history.pushState(null, "", window.location.href);
    window.addEventListener("popstate", blockBack);
    return () => window.removeEventListener("popstate", blockBack);
  }, []);

  return (
    <>
      <Header />

      <div className="flex flex-col items-center bg-blue-50 mt-20 px-6 md:px-12 space-y-8">
        <div className="text-center">
          <h1 className="text-3xl md:text-4xl mt-10 font-bold text-purple-800 tracking-wide">
            Platform Insights
          </h1>
          <p className="mt-2 text-lg md:text-xl text-gray-700">
            Breakdown of user roles, behavior analytics, and monthly signup patterns.
          </p>
        </div>

        <Role allUsers={allUsers} />

        <div className="grid grid-cols-1 md:grid-cols-2 gap-18 mt-10 mb-10 w-full max-w-5xl">
          
          <div className="bg-cyan-50 dark:bg-gray-800 p-6 rounded-xl shadow-lg hover:scale-105 transition-all w-full h-96">
            <h2 className="text-2xl font-semibold text-gray-900 dark:text-white mb-4">
              User Activity
            </h2>
            <UserActivity allUsers={allUsers} />
          </div>

          <div className="bg-cyan-50 dark:bg-gray-800 p-6 rounded-xl shadow-lg hover:scale-105 transition-all w-full h-96">
            <h2 className="text-2xl font-semibold text-gray-900 dark:text-white mb-4">
              Signup Trends
            </h2>
            <SignupTrends allUsers={allUsers} />
          </div>

          <div className="bg-cyan-50 dark:bg-gray-800 p-6 rounded-xl shadow-lg hover:scale-105 transition-all w-full h-96">
            <h2 className="text-2xl font-semibold text-gray-900 dark:text-white mb-4">
              Gender Distribution
            </h2>
            <GenderDistribution allUsers={allUsers} />
          </div>

          <div className="bg-cyan-50 dark:bg-gray-800 p-6 rounded-xl shadow-lg hover:scale-105 transition-all w-full h-96">
            <h2 className="text-2xl font-semibold text-gray-900 dark:text-white mb-4">
              Age Distribution
            </h2>
            <AgeDistribution allUsers={allUsers} />
          </div>
        </div>
      </div>
    </>
  );
};

export default Dashboard;
