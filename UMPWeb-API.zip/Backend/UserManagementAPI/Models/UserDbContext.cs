﻿using Microsoft.EntityFrameworkCore;
using UserManagementAPI.Data;

namespace UserManagementAPI.Models
{
    public class UserDbContext : DbContext
    {
        public UserDbContext(DbContextOptions<UserDbContext> options) : base(options) { }

        public DbSet<UserData> Users { get; set; }
        public DbSet<RoleMaster> MasterRoles { get; set; }
        public DbSet<GenderMaster> MasterGenders { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Seed Roles
            modelBuilder.Entity<RoleMaster>().HasData(
                new RoleMaster { RoleId = 1, RoleName = "Admin" },
                new RoleMaster { RoleId = 2, RoleName = "Customer" },
                new RoleMaster { RoleId = 3, RoleName = "Retailer" }
            );

            // Seed Genders
            modelBuilder.Entity<GenderMaster>().HasData(
                new GenderMaster { GenderId = 1, GenderName = "Male" },
                new GenderMaster { GenderId = 2, GenderName = "Female" },
                new GenderMaster { GenderId = 3, GenderName = "Other" }
            );
        }
    }
}
