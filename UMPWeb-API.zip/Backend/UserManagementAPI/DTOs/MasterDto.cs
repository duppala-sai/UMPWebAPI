﻿using UserManagementAPI.Data;

namespace UserManagementAPI.DTOs
{
    public class MasterDto
    {
        public List<RoleMaster> Roles { get; set; } = new();
        public List<GenderMaster> Genders { get; set; } = new();
    }
}
