﻿public class UserDto
{
    public string FullName { get; set; } = null!;
    public string Email { get; set; } = null!;
    public string Mobile { get; set; } = null!;
    public string Role { get; set; } = null!;
    public string Gender { get; set; } = null!;
    public DateOnly BirthDate { get; set; }
    public DateTime CreatedAt { get; set; }
}
