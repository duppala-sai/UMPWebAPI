﻿using System.ComponentModel.DataAnnotations;
namespace UserManagementAPI.Data
{
    public class UserData
    {
        [Key]
        public int Id { get; set; }

        [Required, MaxLength(100)]
        public string FullName { get; set; } = null!;

        [Required, EmailAddress]
        public string Email { get; set; } = null!;

        [Required]
        public string Password { get; set; } = null!;

        [Required, MaxLength(10)]
        [RegularExpression(@"^[0-9]{10}$", ErrorMessage = "Invalid mobile number")]
        public string Mobile { get; set; } = null!;

        // Foreign key to RoleMaster
        [Required]
        public int RoleId { get; set; }
        public RoleMaster? Role { get; set; }

        // Foreign key to GenderMaster
        [Required]
        public int GenderId { get; set; }
        public GenderMaster? Gender { get; set; }

        [Required]
        public DateOnly BirthDate { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }
}
