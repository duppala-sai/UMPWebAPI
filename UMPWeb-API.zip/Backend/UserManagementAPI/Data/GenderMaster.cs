﻿using System.ComponentModel.DataAnnotations;

namespace UserManagementAPI.Data
{
    public class GenderMaster
    {
        [Key]
        public int GenderId { get; set; }
        [Required, MaxLength(30)]
        public string GenderName { get; set; } = null!;
    }
}
