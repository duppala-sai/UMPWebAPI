﻿using System.ComponentModel.DataAnnotations;

namespace UserManagementAPI.Data
{
    public class RoleMaster
    {
        [Key]
        public int RoleId { get; set; }
        [Required, MaxLength(30)]
        public string RoleName { get; set; } = null!;
    }
}
