import React, { useEffect, useState } from "react";
import { toast } from "react-toastify";
import Header from "../components/header";
import api from "../API/axiosConfig";

const Validation: React.FC = () => {
  const [value, setValue] = useState("");
  const [rules, setRules] = useState<any[]>([]);
  const [results, setResults] = useState<any[]>([]);
  const [emptyError, setEmptyError] = useState("");

  // Fetch all validation rules from backend on mount
  useEffect(() => {
    const fetchRules = async () => {
      try {
        const response = await api.get("/users/validate");
        setRules(response.data);
      } catch (err) {
        toast.error("Failed to fetch validation rules");
      }
    };
    fetchRules();
  }, []);

  const handleValidate = () => {
    // Input empty → show error under field
    if (!value.trim()) {
      setEmptyError("Please enter a value");
      setResults([]);
      return;
    }

    setEmptyError("");

    // If backend returned no rules at all
    if (!rules || rules.length === 0) {
      setResults([
        {
          field: "All",
          result: "Failed",
          message: "No validation rules found from backend",
        },
      ]);
      return;
    }

    const validationResults = rules.map((rule) => {
      // If regexPattern is missing or empty → treat as Failed
      if (!rule.regexPattern || rule.regexPattern.trim() === "") {
        return {
          field: rule.fieldName || "Unknown field",
          result: "Failed",
          message: "Validation rule missing for this field",
        };
      }

      let passed = false;
      try {
        const regex = new RegExp(rule.regexPattern);
        passed = regex.test(value);
      } catch (e) {
        // If regex itself is invalid → also fail
        return {
          field: rule.fieldName || "Unknown field",
          result: "Failed",
          message: "Invalid regex pattern configured in backend",
        };
      }

      return {
        field: rule.fieldName,
        result: passed ? "Passed" : "Failed",
        message: passed ? "" : rule.description,
      };
    });

    setResults(validationResults);
  };

  return (
    <>
      <Header />
      <div className="flex flex-col items-center mt-32">
        <h2 className="text-2xl font-semibold mb-6">Input Validation Summary</h2>

        {/* Input + inline error */}
        <div className="w-80 mb-4">
          <input
            type="text"
            placeholder="Enter value to validate"
            value={value}
            onChange={(e) => {
              setValue(e.target.value);
              setResults([]);
              setEmptyError("");
            }}
            className="border rounded px-3 py-2 w-full"
          />
          {emptyError && (
            <p className="text-red-600 text-sm mt-1">{emptyError}</p>
          )}
        </div>

        <button
          onClick={handleValidate}
          className="bg-green-500 hover:bg-green-600 text-white px-6 py-2 rounded mb-6"
        >
          Validate
        </button>

        {/* Results */}
        <div className="w-2xl">
          {results.map((r, index) => (
            <div
              key={index}
              className={`p-2 mb-2 border rounded ${
                r.result === "Passed" ? "border-green-500" : "border-red-500"
              }`}
            >
              <p>
                <strong>{r.field}:</strong>{" "}
                <span
                  className={
                    r.result === "Passed" ? "text-green-600" : "text-red-600"
                  }
                >
                  {r.result}
                </span>
              </p>
              {r.message && (
                <p className="text-sm text-gray-600"><b>Message:</b> {r.message}</p>
              )}
            </div>
          ))}
        </div>
      </div>
    </>
  );
};

export default Validation;
