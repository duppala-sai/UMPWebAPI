﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace UserManagementAPI.Migrations
{
    /// <inheritdoc />
    public partial class InitialTables : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "MasterGenders",
                keyColumn: "GenderId",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "MasterGenders",
                keyColumn: "GenderId",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "MasterGenders",
                keyColumn: "GenderId",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "MasterRoles",
                keyColumn: "RoleId",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "MasterRoles",
                keyColumn: "RoleId",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "MasterRoles",
                keyColumn: "RoleId",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "ValidationRules",
                keyColumn: "ValidationId",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "ValidationRules",
                keyColumn: "ValidationId",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "ValidationRules",
                keyColumn: "ValidationId",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "ValidationRules",
                keyColumn: "ValidationId",
                keyValue: 4);

            migrationBuilder.DeleteData(
                table: "ValidationRules",
                keyColumn: "ValidationId",
                keyValue: 5);

            migrationBuilder.DeleteData(
                table: "ValidationRules",
                keyColumn: "ValidationId",
                keyValue: 6);

            migrationBuilder.DeleteData(
                table: "ValidationRules",
                keyColumn: "ValidationId",
                keyValue: 7);

            migrationBuilder.DeleteData(
                table: "ValidationRules",
                keyColumn: "ValidationId",
                keyValue: 8);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "MasterGenders",
                columns: new[] { "GenderId", "GenderName" },
                values: new object[,]
                {
                    { 1, "Male" },
                    { 2, "Female" },
                    { 3, "Other" }
                });

            migrationBuilder.InsertData(
                table: "MasterRoles",
                columns: new[] { "RoleId", "RoleName" },
                values: new object[,]
                {
                    { 1, "Admin" },
                    { 2, "Customer" },
                    { 3, "Retailer" }
                });

            migrationBuilder.InsertData(
                table: "ValidationRules",
                columns: new[] { "ValidationId", "Description", "FieldName", "RegexPattern" },
                values: new object[,]
                {
                    { 1, "Full name with only alphabets and spaces (3–40 characters)", "FullName", "^[A-Za-z ]{3,40}$" },
                    { 2, "Username must be 3–20 characters, alphanumeric with underscores", "Username", "^[a-zA-Z0-9_]{3,20}$" },
                    { 3, "Valid email format", "Email", "^[\\w\\.-]+@[A-Za-z]+\\.[A-Za-z]{2,4}$" },
                    { 4, "Indian mobile number (supports +91 format)", "Mobile", "^(?:\\+?91[\\s-]?)?[6-9]\\d{9}$" },
                    { 5, "Password must contain 6+ chars, uppercase, lowercase, number, symbol", "Password", "^(?=.*[A-Z])(?=.*[a-z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{6,}$" },
                    { 6, "Date of birth in YYYY-MM-DD format", "DOB", "^\\d{4}-\\d{2}-\\d{2}$" },
                    { 7, "Aadhar must contain exactly 12 digits", "Aadhar", "^\\d{12}$" },
                    { 8, "Valid Indian PAN format (e.g., ABCDE1234F)", "PAN", "^[A-Z]{5}[0-9]{4}[A-Z]$" }
                });
        }
    }
}
