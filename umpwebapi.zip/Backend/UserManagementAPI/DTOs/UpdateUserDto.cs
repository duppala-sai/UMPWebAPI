﻿namespace UserManagementAPI.DTOs
{
    public class UpdateUserDto
    {
        public string FullName { get; set; } = null!;
        public string Mobile { get; set; } = null!;
        public int RoleId { get; set; }
        public int GenderId { get; set; }
        public DateOnly BirthDate { get; set; }
    }
}
