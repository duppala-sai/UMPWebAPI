﻿namespace UserManagementAPI.DTOs
{
    public class ValidationDto
    {
        public string Value { get; set; } = string.Empty;
    }
}
