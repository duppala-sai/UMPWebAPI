﻿using System.ComponentModel.DataAnnotations;

namespace UserManagementAPI.DTOs
{
    public class RegisterUserDto
    {
        [Required, MaxLength(100)]
        public string FullName { get; set; } = null!;

        [Required, EmailAddress]
        public string Email { get; set; } = null!;

        [Required, MinLength(6)]
        public string Password { get; set; } = null!;

        [Required, MaxLength(10)]
        [RegularExpression(@"^[0-9]{10}$", ErrorMessage = "Invalid mobile number")]
        public string Mobile { get; set; } = null!;

        [Required(ErrorMessage = "Please select a role")]
        public int RoleId { get; set; }  // <-- foreign key to RoleMaster

        [Required(ErrorMessage = "Please select a gender")]
        public int GenderId { get; set; } // <-- foreign key to GenderMaster

        [Required]
        public DateOnly BirthDate { get; set; }
    }
}
