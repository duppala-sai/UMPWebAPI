﻿using BCrypt.Net;
using Microsoft.EntityFrameworkCore;
using UserManagementAPI.DTOs;
using UserManagementAPI.Models;
using UserManagementAPI.Data;

namespace UserManagementAPI.Services
{
    public class UserService
    {
        private readonly UserDbContext _context;
        public UserService(UserDbContext context) => _context = context;

        public async Task<UserDto> RegisterAsync(RegisterUserDto dto)
        {
            if (await _context.Users.AnyAsync(u => u.Email == dto.Email))
                throw new Exception("Email already registered.");

            var user = new UserData
            {
                FullName = dto.FullName,
                Email = dto.Email,
                Password = BCrypt.Net.BCrypt.HashPassword(dto.Password),
                Mobile = dto.Mobile,
                RoleId = dto.RoleId,
                GenderId = dto.GenderId,
                BirthDate = dto.BirthDate,
                CreatedAt = DateTime.UtcNow
            };

            _context.Users.Add(user);
            await _context.SaveChangesAsync();

            await _context.Entry(user).Reference(u => u.Role).LoadAsync();
            await _context.Entry(user).Reference(u => u.Gender).LoadAsync();

            return MapToDto(user);
        }

        public async Task<UserDto> LoginAsync(LoginUserDto dto)
        {
            var user = await _context.Users
                .Include(u => u.Role)
                .Include(u => u.Gender)
                .FirstOrDefaultAsync(u => u.Email == dto.Email);

            if (user == null || !BCrypt.Net.BCrypt.Verify(dto.Password, user.Password))
                throw new Exception("Invalid email or password.");

            return MapToDto(user);
        }

        public async Task<List<UserDto>> GetAllUsersAsync()
        {
            var users = await _context.Users
                .Include(u => u.Role)
                .Include(u => u.Gender)
                .ToListAsync();

            return users.Select(MapToDto).ToList();
        }

        public async Task<UserDto> UpdateUserAsync(string email, UpdateUserDto dto)
        {
            var user = await _context.Users.FirstOrDefaultAsync(u => u.Email == email);
            if (user == null) throw new Exception("User not found.");

            user.FullName = dto.FullName;
            user.Mobile = dto.Mobile;
            user.RoleId = dto.RoleId;
            user.GenderId = dto.GenderId;
            user.BirthDate = dto.BirthDate;

            await _context.SaveChangesAsync();

            await _context.Entry(user).Reference(u => u.Role).LoadAsync();
            await _context.Entry(user).Reference(u => u.Gender).LoadAsync();

            return MapToDto(user);
        }

        public async Task DeleteUserAsync(string email)
        {
            var user = await _context.Users.FirstOrDefaultAsync(u => u.Email == email);
            if (user == null) throw new Exception("User not found.");

            _context.Users.Remove(user);
            await _context.SaveChangesAsync();
        }

       
        public async Task<MasterDto> GetLookupsAsync()
        {
            var masterdata = new MasterDto
            {
                Roles = await _context.MasterRoles
                    .Select(r => new RoleMaster { RoleId = r.RoleId, RoleName = r.RoleName })
                    .ToListAsync(),
                Genders = await _context.MasterGenders
                    .Select(g => new GenderMaster { GenderId = g.GenderId, GenderName = g.GenderName })
                    .ToListAsync()
            };
            return masterdata;
        }

        //vaidation rule
        // Validation rule using DTO
        public async Task<List<ValidationRule>> GetValidationRulesAsync()
        {
            return await _context.ValidationRules.ToListAsync();
        }



        //validation rule



        private UserDto MapToDto(UserData user)
        {
            return new UserDto
            {
                FullName = user.FullName,
                Email = user.Email,
                Mobile = user.Mobile,
                Role = user.Role?.RoleName ?? "",
                Gender = user.Gender?.GenderName ?? "",
                BirthDate = user.BirthDate,
                CreatedAt = user.CreatedAt
            };
        }
    }
}
