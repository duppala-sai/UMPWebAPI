﻿using Microsoft.EntityFrameworkCore;
using UserManagementAPI.Data;

namespace UserManagementAPI.Models
{
    public class UserDbContext : DbContext
    {
        public UserDbContext(DbContextOptions<UserDbContext> options) : base(options) { }

        public DbSet<UserData> Users { get; set; }
        public DbSet<RoleMaster> MasterRoles { get; set; }
        public DbSet<GenderMaster> MasterGenders { get; set; }
        public DbSet<ValidationRule> ValidationRules { get; set; }

      /*  protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Seed Roles
            modelBuilder.Entity<RoleMaster>().HasData(
                new RoleMaster { RoleId = 1, RoleName = "Admin" },
                new RoleMaster { RoleId = 2, RoleName = "Customer" },
                new RoleMaster { RoleId = 3, RoleName = "Retailer" }
            );

            // Seed Genders
            modelBuilder.Entity<GenderMaster>().HasData(
                new GenderMaster { GenderId = 1, GenderName = "Male" },
                new GenderMaster { GenderId = 2, GenderName = "Female" },
                new GenderMaster { GenderId = 3, GenderName = "Other" }
            );

            // Seed Validation Rules
            modelBuilder.Entity<ValidationRule>().HasData(

                 new ValidationRule
                 {
                     ValidationId = 1,
                     FieldName = "FullName",
                     RegexPattern = @"^[A-Za-z ]{3,40}$",
                     Description = "Full name with only alphabets and spaces (3–40 characters)"
                 },
                 new ValidationRule
                 {
                     ValidationId = 2,
                     FieldName = "Username",
                     RegexPattern = @"^[a-zA-Z0-9_]{3,20}$",
                     Description = "Username must be 3–20 characters, alphanumeric with underscores"
                 },

                new ValidationRule
                {
                    ValidationId = 3,
                    FieldName = "Email",
                    RegexPattern = @"^[\w\.-]+@[A-Za-z]+\.[A-Za-z]{2,4}$",
                    Description = "Valid email format"
                },
                new ValidationRule
                {
                    ValidationId = 4,
                    FieldName = "Mobile",
                    RegexPattern = @"^(?:\+?91[\s-]?)?[6-9]\d{9}$",
                    Description = "Indian mobile number (supports +91 format)"
                },
                new ValidationRule
                {
                    ValidationId = 5,
                    FieldName = "Password",
                    RegexPattern = @"^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{6,}$",
                    Description = "Password must contain 6+ chars, uppercase, lowercase, number, symbol"
                },

                new ValidationRule
                {
                    ValidationId = 6,
                    FieldName = "DOB",
                    RegexPattern = @"^\d{4}-\d{2}-\d{2}$",
                    Description = "Date of birth in YYYY-MM-DD format"
                },

                new ValidationRule
                {
                    ValidationId = 7,
                    FieldName = "Aadhar",
                    RegexPattern = @"^\d{12}$",
                    Description = "Aadhar must contain exactly 12 digits"
                },
                new ValidationRule
                {
                    ValidationId = 8,
                    FieldName = "PAN",
                    RegexPattern = @"^[A-Z]{5}[0-9]{4}[A-Z]$",
                    Description = "Valid Indian PAN format (e.g., ABCDE1234F)"
                }
                
            );
        }    */
     
    }
}
