﻿using System.ComponentModel.DataAnnotations;

namespace UserManagementAPI.Data
{
    public class ValidationRule
    {
        [Key]
        public int ValidationId { get; set; }
        public string FieldName { get; set; } = string.Empty;
        public string RegexPattern { get; set; } = string.Empty;
        public string? Description { get; set; }
    }
}
